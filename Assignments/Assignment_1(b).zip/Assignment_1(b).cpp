#include<iostream>
using namespace std;
int main()
{
	cout<<"\nEnter Three Numbers:";
	int a,b,c;
	cin>>a>>b>>c;
	cout<<"\nMax Number:";
	if(a>b)
	{
		if(a>c)
			cout<<a;
	}
	else
	{
		if(b>c)
			cout<<b;
		else
			cout<<c;
	}
}
