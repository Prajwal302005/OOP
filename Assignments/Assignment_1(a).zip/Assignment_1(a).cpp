#include<iostream>
using namespace std;
int main()
{
	cout<<"Enter Two Numbers:";
	int a,b;
	cin>>a>>b;
	cout<<"\nAddition:";
	cout<<a+b;
	cout<<"\nSubtraction:";
	cout<<a-b;
	cout<<"\nMultiplication:";
	cout<<a*b;
	cout<<"\nDivision:";
	cout<<a/b;
	cout<<"\nModules:";
	cout<<a%b;
	
}
